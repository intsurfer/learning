const numDivs = 36;
const maxHits = 10;

let hits = 0;
let firstHitTime = 0;

function round() {
  $('.game-field').removeClass('target').removeClass('miss').text("");
  let divSelector = randomDivId();
  $(divSelector).addClass("target");
  $(divSelector).text(hits+1);
  // Запуск по кнопке, поэтому не нужно использовать
  //firstHitTime = getTimestamp();

  if (hits === maxHits) {
    endGame();
  }
}

function endGame() {
  $('.game-field').removeClass('target').removeClass('miss').text("");
  $('.row').hide();
  $('.footer').show();
  let totalPlayedMillis = getTimestamp() - firstHitTime;
  let totalPlayedSeconds = Number(totalPlayedMillis / 1000).toPrecision(3);
  $("#total-time-played").text(totalPlayedSeconds);

  $("#win-message").removeClass("d-none");
}

function handleClick(event) {
  let divSelector = $(event.target);
  $(divSelector).text("");
  if ($(event.target).hasClass("target")) {
    hits += 1;
    round();
  } else {
	$(event.target).addClass('miss');
	hits -= 1;
	if(hits < 0) hits = 0;
    round();
  }
  // TODO: как-то отмечать если мы промахнулись? См CSS класс .miss
}

function init() {
  $(".game-field").click(handleClick);
  $("#button-reload").click(function() {
	$("#win-message").addClass("d-none"); 
	$('.row').show();
	$('.game-field').removeClass('target').removeClass('miss').text("");
	hits = 0;
	let divSelector = randomDivId();
	$(divSelector).addClass("target");
	$(divSelector).text(1);
    firstHitTime = getTimestamp();
  });
}

$(document).ready(init);
